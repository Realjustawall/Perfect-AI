# Perfect_AI OMEGA — Codex superpack (No MCP)

**187 original local installable Codex Skills**, including all 91 previous and 96 new focused skills. **279 VibeFarsi implementation specifications**, 47 GitHub references (upstream not copied), 49 total deep reference guides (01–13, 15–50), 30 responsive component patterns, Anime.js/Three.js example, Motion+GSAP+Animate.css example, responsive offline example, color-engine and browser test tools. Source code for third-party proprietary websites is not bundled.

See [`README-FA.md`](README-FA.md) for installation, usage, testing and licensing details in Persian.

## Essential references
- `skills/perfect-ai-master/references/22-responsive-engineering-foundations.md`: broad responsive engineering
- `skills/perfect-ai-master/references/23-container-query-design-system.md`: named container query composition
- `skills/perfect-ai-master/references/26-scroll-choreography-responsive.md`: scroll + 3D responsive staging
- `skills/perfect-ai-master/references/30-responsive-audit-test-matrix.md`: verified responsive test plan
- `skills/perfect-ai-master/references/36-advanced-color-science.md`: perceptual color theory and standards
- `skills/perfect-ai-master/references/37-color-algorithm-workbook.md`: palette decisions and contrast
- `skills/perfect-ai-master/references/32-motion-libraries-decision-tree.md`: Anime.js vs Motion animate() vs GSAP vs Animate.css
- `skills/perfect-ai-master/references/46-advanced-webgl-and-shader-systems.md`: Three.js shader/geometry

## Run
- Windows: `.\install\install-codex.ps1 -ProjectPath "C:\Projects\YourWebsite"`
- Cross-platform: `bash install/install-codex.sh /path/to/project`
- Tests: `node --test tests/omega-validation.test.mjs tests/palette-decision.test.mjs tests/color-engine.test.mjs`
- Chromium responsive audit: `node tools/browser-matrix.mjs examples/responsive-lab/index.html --output reports`
- Palette CLI: `node tools/palette-decision.mjs --monochrome --out palette-output`

**Install upstream VibeFarsi** only after review, via bundled CLI shell scripts. No MCP is used.
