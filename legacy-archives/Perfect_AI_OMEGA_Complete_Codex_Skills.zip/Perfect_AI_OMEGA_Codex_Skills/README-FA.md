# راهنمای نصب مجموعهٔ Perfect_AI OMEGA برای Codex

این بسته تمام اجزای نسخهٔ ULTRA را حفظ می‌کند و ساختار آن توسعه یافته است: مهارت‌های Anime.js، Three.js، رنگ‌شناسی OKLCH، ۲۷۹ راهنمای VibeFarsi، فهرست GitHub، تست‌ها، RTL، UI/UX، امنیت و DevOps. علاوه بر این، Skillهای جدید ریسپانسیو، Motion، Animate.css، GSAP، اجرای بومی CSS/WAAPI، سیستم تم، دسترس‌پذیری و نمونه‌های عملی وجود دارد. **MCP لازم نیست.**

## نصب در ویندوز / PowerShell
پوشه ZIP را استخراج کنید و در خود پوشه اجرا کنید:

```powershell
.\install\install-codex.ps1 -ProjectPath "C:\Projects\YourWebsite"
```

Skillها به `C:\Projects\YourWebsite\.agents\skills` کپی می‌شوند. برای نصب مجدد روی همان مسیر در صورت نیاز از `-Force` استفاده کنید؛ قبل از جایگزینی از تغییرات محلی پشتیبان بگیرید.

## نمونهٔ دستور Codex

```text
Use $perfect-ai-master together with $ztx-responsive-architecture,
$ztx-responsive-container-queries, $ztx-color-decision,
$ztx-motion-animejs-layout, $zt-three-scene and $ztx-engineering-regression.
Read matching references and executable examples. Keep all existing functionality.
Build a bilingual Persian/English responsive cinematic website with proper
monochrome Perfect_AI identity, semantic HTML, working controls, real 3D
only where justified, correct reverse-scroll timelines and no MCP.
Test widths 320/390/768/1024/1440, 200/400% zoom, keyboard,
reduced motion, failed WebGL, and report measured results only.
```

## اجرای تست‌ها
```powershell
node --test .\tests\omega-validation.test.mjs
node --test .\tests\palette-decision.test.mjs
node --test .\tests\color-engine.test.mjs
node .\tools\palette-decision.mjs --product developer --mode dark --monochrome --out .\palette-output
node .\tools\browser-matrix.mjs .\examples\responsive-lab\index.html --output .\reports
```

آخرین دستور به Node 22 و نصب Chrome/Chromium نیاز دارد. تست‌های داخلی جایگزین آزمایش واقعی iOS/Safari یا دستگاه‌های ضعیف نیستند.

## VibeFarsi بدون MCP
راهنماهای تمام ۲۷۹ مورد داخل `skills/perfect-ai-master/registry/vibefarsi-items` هستند. فایل کد اصلی این کامپوننت‌ها در ZIP کپی نشده‌اند. برای نصب واقعی موارد موجود در رجیستری VibeFarsi (نیازمند اینترنت):

```powershell
.\install\install-vibefarsi-all.ps1 -ProjectPath "C:\Projects\YourWebsite"
.\install\install-vibefarsi-all.ps1 -ProjectPath "C:\Projects\YourWebsite" -Execute -OnlyCategories animations,components
```

قبل از اجرای تمام موارد، سازگاری نسخهٔ رجیستری، مجوزها و وابستگی‌ها را بررسی کنید. تمام موارد صرفاً برای شمارش در یک باندل تولیدی وارد نمی‌شوند.

## GitHub
فهرست ۴۷ منبع انتخابی نسخهٔ قبلی حفظ شده است. این‌ها لینک و راهنمای ارزیابی‌اند؛ برای واردکردن سورس یک Skill خارجی از `install/import-github-skill.ps1` فقط پس از بررسی مجوز و اعتماد به منبع استفاده کنید. هیچ اسکریپت نصب خودکار بدون تأیید اجرا نمی‌شود.

## مرزهای ادعا
وجود Skill یا راهنما به‌معنی ساخته‌شدن اتوماتیک همهٔ کامپوننت‌ها در یک وب‌سایت نیست؛ Codex هنگام اجرای هر وظیفه آن را پیاده‌سازی و تست می‌کند. کد اختصاصی سایت Anime.js یا VibeFarsi بدون مجوز یا از روی حدس به‌عنوان کد اصلی معرفی نمی‌شود. موتور Animate.js نامی مبهم است؛ در مرجع تفاوت Anime.js، Motion animate(), Animate.css و GSAP صریح آمده است.

## آزمایشگاه چند موتور انیمیشن
در مسیر `examples/motion-engines-lab` کد اجرایی Anime.js v4، Motion `animate()`، GSAP و Animate.css وجود دارد. فایل‌های اصلی کتابخانه‌ها داخل ZIP نیستند؛ برای نصب وابستگی‌ها به اینترنت نیاز است:

```powershell
cd .\examples\motion-engines-lab
npm install
npm run dev
```

## اجرای Chromium در ویندوز
اگر فرمان `chromium` پیدا نمی‌شود، می‌توانید Chrome محلی را معرفی کنید:

```powershell
$env:CHROME_BIN = "C:\Program Files\Google\Chrome\Application\chrome.exe"
node .\tools\browser-matrix.mjs .\examples\responsive-lab\index.html --output .\reports
```

این تست فقط آزمایشگاه مستقل `responsive-lab` را بدون شبکه در مرورگر تزریق می‌کند؛ برای اپلیکیشن‌های پیچیده‌تر از Playwright/E2E پروژه استفاده کنید.
