---
name: perfect-ai-master
description: Build, audit, and refactor premium Persian/English responsive websites and interactive 3D experiences with Anime.js v4, Three.js, motion choreography, color theory, RTL design systems, accessible UI/UX and VibeFarsi registry. Use for website design, animations, motion, landing pages, 3D/WebGL, responsive interfaces, visual quality, or Perfect_AI projects in Codex.
---

# Perfect_AI — Codex Master Skill

> A practical engineering playbook, not a promise of pixel-perfect cloning or access to third-party private source files. Built from original guidance with links to official documentation and VibeFarsi catalog entries. Read the relevant referenced files before implementing.

## Non-negotiable execution protocol

1. **Inspect** the repo, package manager, frameworks, baseline look, existing code, fonts, accessible semantics and performance budget. Keep working behavior. Never overwrite user files without checking. List major entrypoints.
2. **Define** objective, target audience, language(s), content, content hierarchy, direction, supported devices, interaction model, performance target, color/theme, and reference URLs. Use provided constraints rather than asking again.
3. **Reference decomposition:** for each sample site screenshot or URL break down shell, header, hero, 3D object geometry/material, typography, sticky/scroll phases, color, effects, layout, motion timeline, text, sections and responsive variants. Distinguish *observed* from *inferred* and *not verified*. Do not claim to have extracted exact original geometry or code without doing so.
4. **Architect:** choose native CSS for basic states, Anime.js v4 for orchestrated DOM/SVG/text/scroll, Three.js for truly 3D WebGL/WebGPU, and VibeFarsi components for Persian RTL UI. Pick one owner for each property: no Anime.js/CSS/Three.js competing transforms on the same node.
5. **Build progressively:** static accessible HTML first; mobile-first layout; typographic/token system; functional controls; scroll triggers; restrained enhancement; real 3D; performance fallback; reduced-motion handling; tests.
6. **Run:** install/build/typecheck/lint/tests; use a browser if present to inspect desktop/tablet/mobile, slow scroll, reverse scroll, focus/keyboard, low-power, RTL, reduced motion and browser console. Fix and recheck. Do not claim unseen tests passed.
7. **Report** files changed, what is implemented, what requires dependencies, browser checks done, measured vs target values, remaining caveats.

## Read exactly the matching reference modules

| Task | Primary reference | Supporting reference |
| --- | --- | --- |
| Anime.js animations, text, SVG, scroll | `references/01-animejs-motion.md` | `references/06-motion-recipes.md` |
| Three.js, point clouds, shaders, morphing | `references/02-threejs-3d.md` | `references/10-perfect-ai-experience.md` |
| Color theory, dark monochrome, token design | `references/03-color-theory.md` | `references/04-ui-ux-system.md` |
| UI/UX design, interactions, information architecture | `references/04-ui-ux-system.md` | `references/08-quality-tests.md` |
| Responsive / mobile / touch / RTL | `references/05-responsive-rtl.md` | `references/09-persian-localization.md` |
| Named animation recipes | `references/06-motion-recipes.md` | `references/01-animejs-motion.md` |
| VibeFarsi: **every listed registry entry** | `references/07-vibefarsi-full-catalog.md` | `references/09-persian-localization.md` |
| Test/audit/production ship | `references/08-quality-tests.md` | `references/11-workflow-architecture.md` |
| Iran/Persian language, form, dates, SEO | `references/09-persian-localization.md` | catalog Skill entries |
| Rebuild/extend user's Perfect_AI website | `references/10-perfect-ai-experience.md` | three, motion, color, responsive |
| Architecture, implementation patterns, dependency conflicts | `references/11-workflow-architecture.md` | quality tests |
| Source-of-truth links and version checks | `references/12-sources-and-rights.md` | official docs |
| Three.js individual animation mechanisms | `references/13-threejs-animation-atlas.md` | `references/02-threejs-3d.md` |
| VibeFarsi MCP and upstream installation | `references/14-vibefarsi-mcp-install.md` | `references/07-vibefarsi-full-catalog.md` |

## Mandatory design rules

- **Real content first.** No empty fake buttons, invented testimonials or fake metrics. Every interaction has a defined outcome and keyboard equivalent.
- **Direction:** `lang="fa" dir="rtl"` for Persian; isolate URLs, numbers, code, model names in `dir="ltr"` or `<bdi>`. Use logical layout properties (`margin-inline-start`), avoid accidental double reversal.
- **Perfect_AI default visual:** genuinely black/white with a layered neutral ramp; no random cyan/purple/pink gradients. If another theme is explicitly requested, apply system tokens and check contrast.
- **Semantics:** one h1; ordered sections; meaningful labels; focus-visible; no canvas-only critical content; real links; ARIA only when native HTML is inadequate.
- **Motion:** every animated experience has initial/final states, a time/progress model, interruption/reversal strategy, ownership, fallback and cleanup. Respect `prefers-reduced-motion`.
- **Scroll:** use a single normalized progress signal, clamped 0..1; use rAF/coalesced updates, avoid forced layout inside the frame, ensure reverse scroll and short viewport correctness.
- **3D:** define actual topology (mesh/geometry/particles), camera, materials, lighting, render pipeline, animation, resolution and fallback. A 2D radial canvas is not automatically a 3D mesh. Inspect performance of transparent particles and postprocessing.
- **Quality:** no horizontal overflow at 320 CSS px; no text trapped behind the orb or fixed nav; avoid 100vh keyboard bugs; mobile tap targets generally >=44 CSS px; document zoom 200%; functionality without WebGL.
- **Color:** use semantic tokens and distinguish decoration from information. Check WCAG 2.2 contrast targets, not eyeballing.
- **Rights:** do not misrepresent third-party implementations as original or automatically copy proprietary page scripts/assets. Reuse open-source code only when permitted by its LICENSE and keep credits when required. For VibeFarsi official files, install via its published CLI if desired; local guidance is independent.

## Implementation decision tree

- One-off hover/focus transition? CSS transitions with `transform` and `opacity`.
- Enter/reveal/count/stagger/SVG path/interactive timeline? Anime.js v4.
- Scroll choreography involving DOM? Anime.js `onScroll` or a single scroll-controller with explicit `progress`.
- Dense particles, morphing 3D, glTF, HDR lighting? Three.js (choose BufferGeometry, InstancedMesh, Points, ShaderMaterial, AnimationMixer as appropriate).
- CSS-only rich RTL components desired? Look up `07-vibefarsi-full-catalog.md` and use official `npx vibefarsi add <slug>` where permitted.
- Visually delicate foreground text? Keep DOM HTML separate from a `pointer-events:none` 3D canvas; never rasterize text without reason.
- Device cannot support full effect? Static SVG/poster or lower-density animation fallback that preserves content.

## Working definition of finished

- [ ] At least one deliberate responsive layout for 320/375/768/1024/1440 widths.
- [ ] No console/runtime/build issues observed during completed tests.
- [ ] Scroll motion is bidirectional, bounded, and independent of frame rate.
- [ ] Color and typography tokens centralised; bright glow never replaces readable text.
- [ ] Keyboard and screen-reader accessible alternatives; reduced-motion mode.
- [ ] No infinite rAF after component unmount/navigation.
- [ ] Clearly report tests run and unverified areas.

## Suggested invocations

- `Use $perfect-ai-master to audit and rebuild this React landing page in monochrome with true 3D and Anime.js text transitions; read all relevant references first.`
- `Use $perfect-ai-master to build a responsive bilingual RTL site with VibeFarsi components, 3D product viewer, accessible form, and performance tests.`
- `Use $perfect-ai-master and apply the Perfect_AI scroll-experience spec, preserving existing content and source code.`
