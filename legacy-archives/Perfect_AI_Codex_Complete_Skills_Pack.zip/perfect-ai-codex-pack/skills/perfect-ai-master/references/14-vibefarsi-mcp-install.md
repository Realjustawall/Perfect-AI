# VibeFarsi — exact upstream installation, MCP, guides vs skills

Verified against https://vibefarsi.ir/docs and https://vibefarsi.ir/skills, 2026-10-09.

## Classification of the 14 listed resources

**VibeFarsi-agent skills with `SKILL.md` (7):**
`persian-conversational`, `persian-formal`, `persian-ui-copy`, `persian-rtl-ui`, `jalali-calendar`, `iran-validation`, `persian-seo`.

**Markdown guides rather than automatically discovered skills (6):**
`agents-md-persian`, `ui-craft-rules`, `persian-typography`, `parspack-s3-upload`, `zarinpal-payment`, `kavenegar-otp`. Official page says guides have no frontmatter and should be linked from `AGENTS.md` / `CLAUDE.md`.

**External skill (1):** `persian-writing`, maintained at https://github.com/ali2000hos/persian-writing (MIT per VibeFarsi page). Review its own instructions before installing; VibeFarsi's `npx` CLI doesn't maintain this item.

The **14 independent `zt-*` local skill files** supplied in this pack are newly written Codex modules that help apply these domains without needing access to their official source. They are not verbatim copies of official materials and are not falsely described as that.

## Installing official VibeFarsi UI artifacts into a React project

Prerequisites: Node/npm or pnpm/npx, React (Next.js or Vite), Tailwind v4, internet. Review project state and back up modified files or commit changes before running.

```powershell
npx vibefarsi@latest init
npx vibefarsi list
npx vibefarsi add button calendar price
npx vibefarsi add text-shimmer orbit reveal
npx vibefarsi add graphite
```

`init` establishes RTL, Vazirmatn, design tokens and AGENTS.md rules. For non-destructive preview use documented `--dry-run` where supported. `add` writes source files within project rather than importing one monolithic component npm package.

Codex agent-skill path (project-local): `.agents/skills/<slug>/SKILL.md`. For an upstream skill installed under `.claude/skills/`, copy it to `.agents/skills/` if it does not already exist. The six Markdown guides should reside under `docs/` and be referenced by project `AGENTS.md` rather than pretending to be SKILL.md files.

## Optional MCP for Codex

From the official VibeFarsi documentation:

```powershell
codex mcp add vibefarsi --url https://vibefarsi.ir/mcp
```

This command is an **optional external connection**, and must be invoked by the user/agent in their environment; do not assert it is installed when merely documented.

Advertised MCP tools:

| MCP tool | How to call it in workflow |
| --- | --- |
| `get_design_rules` | Read RTL, font, number, forms and token requirements before generating UI |
| `search_registry` | Discover matching UI/animation/background/theme by intent and slug |
| `get_component` | Fetch complete component code/instructions/required dependencies |
| `get_theme` | Fetch semantic theme tokens such as graphite; don't invent unrelated colors |
| `scaffold_page` | Create composed page plan from a page objective like checkout, OTP, booking |

After MCP connection, verify available tool signatures and follow them; never invent payload schemas. Check license, dependencies, and outputs before writing files. If MCP unavailable, rely on bundled catalog and official CLI/manual instructions.

## Three installation tiers

- **Offline zero-dependency knowledge:** install bundled `perfect-ai-master` and `zt-*` modules; reference docs and example files available locally.
- **Upstream source components:** install VibeFarsi CLI and chosen components on demand into a React app.
- **Current online registry through Codex:** add VibeFarsi MCP, inspect actual tool list, retrieve current docs and source when necessary.

## Integrating VibeFarsi + Anime.js + Three.js

VibeFarsi animation components generally use React and CSS without another animation library. If choosing an official `reveal`/`orbit` component, respect its own animation lifecycle and don't animate the same DOM element with Anime.js simultaneously. Three.js canvas should remain a separate graphical layer. Shared styling through semantic CSS tokens (e.g., graphite), and all UI interactions must have browser and keyboard fallbacks.

## Rights/safety notes

Running `npx` or adding external MCP executes or connects to external providers. Review the repo and permissions, never expose keys and personal data unnecessarily. VibeFarsi source outputs belong under their licensing terms; local `zt-*` instructions are independent and do not imply distribution of the original upstream code.
