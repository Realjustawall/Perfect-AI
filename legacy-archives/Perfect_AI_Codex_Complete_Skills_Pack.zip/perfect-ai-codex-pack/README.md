# Perfect_AI — Codex Motion, 3D, UI/UX & VibeFarsi Skill Pack

**Generated 2026-10-09.** Original instructional content for Codex. Complete public VibeFarsi catalog index (279 slugs) and **15 installable local skills** (1 master + 14 independently authored focused skills). Includes comprehensive Anime.js v4 / Three.js / CSS/RTL/color theory / UX / QA references and code examples.

## Windows install (your Codex project)

1. Unzip the entire package into a temporary directory.
2. Open PowerShell and run: `powershell -ExecutionPolicy Bypass -File .\install\install-codex.ps1 -ProjectPath "C:\path\to\your\project"`
3. This copies the 15 local skill folders into your project's `.agents\skills\` without replacing existing ones.
4. Restart Codex, and use the prompt: `Use $perfect-ai-master and read the Anime.js, Three.js, color theory, UI/UX, responsive, VibeFarsi catalog and Perfect_AI references before building this site.`

On Linux/macOS: `bash install/install-codex.sh /path/to/project`. Or copy `skills/perfect-ai-master/` into `.agents/skills/` manually.

**Important:** The 14 bundled `zt-*` skills are independent local adaptations — **NOT** original VibeFarsi-authored source files. Want the upstream listed VibeFarsi materials (7 agent skills + 6 guides + 1 externally maintained writing skill)? First inspect https://vibefarsi.ir/docs, then run `install/install-vibefarsi-official.ps1` with `-Install` in a compatible project (uses internet and official registry for 13 items; won't overwrite installed Codex skill dirs). For the separately maintained `persian-writing` read https://vibefarsi.ir/skills/persian-writing and install from its author's GitHub repository. To install only one upstream skill: `npx vibefarsi add persian-rtl-ui` etc. (for authored skills; guides live under `docs/`), and place official SKILL.md in Codex `.agents/skills/slug/`.

## Inventory

- `skills/perfect-ai-master/SKILL.md`: task discovery, workflow, routing and quality gates
- `skills/perfect-ai-master/references/01...13...md`: deep documentation with original recipes
- `skills/perfect-ai-master/references/07-vibefarsi-full-catalog.md`: **279** catalog entries with each slug's usage, integration and test strategy
- `skills/zt-*/SKILL.md`: **14** specialized independent Persian/Iranian skill adaptations
- `registry-index.json`: machine-readable catalog by category
- `install/`: safe copy installers; optional upstream downloader
- `examples/`: code snippets and Node.js tests

## What is / is not included

- Includes exhaustive *families and a large named set of patterns* for Anime.js and Three.js and VibeFarsi catalog items.
- Does not include private source of animejs.com, site-specific 3D assets, VibeFarsi-maintained `SKILL.md` originals or live downloaded React components. The maintained VibeFarsi materials can be installed officially.
- The official VibeFarsi registry is not a dependency automatically installed. The master instructions work without network; actual `npx` installs need access.
- 'All possible animations' cannot be literally enumerated in libraries that allow arbitrary procedural animation. The reference catalogs mechanisms and named public patterns, with verified source links and implementation guidance.

## Validation

Use `python tools/validate_pack.py` to check local skill names, reference targets, catalog counts and files. Use `node --test skills/perfect-ai-master/examples/scroll-controller.test.mjs` for the included scroll math tests. This does not replace actual browser/device QA.

## Upstream references

- https://animejs.com/documentation
- https://threejs.org/docs/
- https://vibefarsi.ir/skills
- https://vibefarsi.ir/docs
- https://developers.openai.com/plugins/build/skills

## Optional live VibeFarsi MCP (Codex)

The official VibeFarsi docs currently advertise `codex mcp add vibefarsi --url https://vibefarsi.ir/mcp`. This connection is **optional**, requires user action, and provides tools such as `get_design_rules`, `search_registry`, `get_component`, `get_theme`, and `scaffold_page`. Our skill pack makes no MCP connection automatically.
