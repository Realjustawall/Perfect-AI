<#
OPTIONAL: Get the 7 upstream VibeFarsi agent skills + 6 Markdown guides via the OFFICIAL registry CLI.
The 14th catalog item `persian-writing` is externally maintained and is not included.
Requires Node.js, npm/npx, internet. This executes third-party code only on explicit user request.
Run from the root of an existing compatible Next/Vite React+Tailwind project.
Carefully review VibeFarsi docs and CLI changes first; use -Install to opt in.
#>
param([string]$ProjectPath=(Get-Location).Path,[switch]$Install)
$ErrorActionPreference='Stop'
$authorSkills=@('persian-conversational','persian-formal','persian-ui-copy','persian-rtl-ui','jalali-calendar','iran-validation','persian-seo')
$guides=@('agents-md-persian','ui-craft-rules','persian-typography','parspack-s3-upload','zarinpal-payment','kavenegar-otp')
$slugs=$authorSkills+$guides
Write-Host "Source: https://vibefarsi.ir/docs ; 7 upstream agent skills, 6 reference guides; external persian-writing separately at github.com/ali2000hos/persian-writing"
Write-Host "Project: $ProjectPath"
$slugs | ForEach-Object { Write-Host "npx vibefarsi add $_" }
if (-not $Install) { Write-Host 'Preview only. Pass -Install to execute upstream CLI.'; exit 0 }
if (-not (Test-Path (Join-Path $ProjectPath 'package.json'))) { throw 'Expected package.json in an existing project' }
Push-Location $ProjectPath
try {
  foreach($slug in $slugs) {
    & npx vibefarsi add $slug
    if ($LASTEXITCODE -ne 0) { throw "Upstream CLI failed for $slug" }
  }
  $codex=Join-Path $ProjectPath '.agents\skills'; New-Item -ItemType Directory -Path $codex -Force | Out-Null
  foreach($slug in $authorSkills) {
    $from=Join-Path $ProjectPath ".claude\skills\$slug"
    $to=Join-Path $codex $slug
    if ((Test-Path (Join-Path $from 'SKILL.md')) -and -not (Test-Path $to)) { Copy-Item -LiteralPath $from -Destination $to -Recurse; Write-Host "COPIED upstream skill $slug to Codex" }
    elseif (Test-Path $to) { Write-Host "SKIP existing Codex skill $slug" }
    else { Write-Warning "Official CLI output not found at expected $from; check the VibeFarsi docs/manual Codex path." }
  }
  foreach($slug in $guides) { Write-Host "UPSTREAM GUIDE $slug: look in docs/ or CLI output. Guides do not have SKILL.md and must be referenced from AGENTS.md." }
}
finally { Pop-Location }
