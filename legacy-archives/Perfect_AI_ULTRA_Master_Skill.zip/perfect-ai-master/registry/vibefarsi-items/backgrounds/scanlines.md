# VibeFarsi item: `scanlines` (backgrounds)

- **Origin/catalog**: https://vibefarsi.ir/backgrounds/scanlines
- **Official install** (in compatible project; after CLI dry run): `npx vibefarsi add scanlines`
- **Source status here**: original behavior specification, **NOT downloaded upstream component source**.

## Functional behavior
Implement a `scanlines` from the official registry if installed; otherwise build an independently authored component matching user requirements. Define props, events, states, accessible names, user interactions and error outcomes before visuals.

## Integration plan
1. Inspect existing React project, Tailwind v4, locale, icon system and tokens.
2. `npx vibefarsi add scanlines --dry-run` and review proposed files; install only if desired/compatible.
3. Create a demo route with actual data/content, one responsive mobile viewport and desktop viewport.
4. **Layer recipe and compositing order**: handle text contrast over brightest region, pointer events disabled, reduced motion fallback.
5. If enhancing with Anime.js, isolate animated wrapper from library's own state transforms; test cleanup and reduced motion.

## Unique implementation recipe
**Layer rule**: render behind text, use pointer-events none and preserve WCAG contrast after actual compositing. For Canvas/WebGL throttle DPR and stop when offscreen.

## Acceptance tests
- No focus loss, clipping or overflow, stable layout on small widths.
- No hidden critical content when JS/animation is disabled.
- If installed, compare markup against actual upstream source and adapt without removing license notices.
