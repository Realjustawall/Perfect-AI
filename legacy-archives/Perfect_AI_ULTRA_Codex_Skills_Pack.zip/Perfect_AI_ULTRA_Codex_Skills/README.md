# Perfect_AI ULTRA — Codex Skills Pack (2026-10-09)

**No MCP.** Installable offline-authored Codex instructions + executable local tools + optional install of official VibeFarsi files using its published npm CLI (needs network to fetch first time).

## Inventory / truth in packaging

- **91 local installable Codex Skills**: 1 master + 14 legacy independent Persian support Skills + 76 new focused original Skills (Animation, WebGL, color, UX, RTL, React, security, QA, VibeFarsi).
- **279 individual VibeFarsi item specifications** in `registry/vibefarsi-items/<category>/<slug>.md` (also inside master Skill); includes **63 motion** + 44 backgrounds + 78 components and other blocks, charts, templates, sites and themes.
- **47 GitHub upstream references** in `github-skills-catalog.json` and master `references/15-github-curated-skills.md`. Their original SKILL.md/code are **not bundled** and must be reviewed for license and imported separately. Our 91 Skills are independently authored.
- **20 deep master reference modules** (01–13, 15–21; no module 14: dropped dependency on remote connector).
- **Executable OKLCH to sRGB gamut mapping, WCAG contrast audit and semantic palette engine** (`tools/color-engine.mjs`, `tools/create-palette.mjs`), including unit tests and zero-random-color Perfect_AI monochrome mode.
- **Live Anime.js + Three.js code example** (`examples/live-lab`), actual mesh/particles/lighting/scroll/text timeline; runs after `npm install` in its directory. It is not the proprietary animejs.com site source.
- Safe install scripts for Windows/Linux. Do not overwrite existing Codex skill directories unless explicitly requested.

## 1. Install 91 skills to Codex (Windows)

Extract the ZIP, open PowerShell *in the extracted directory*:

```powershell
.\install\install-codex.ps1 -ProjectPath "C:\Projects\my-web-app"
```

This copies `skills/*` to `<project>/.agents/skills/`. Restart Codex or begin a new session. For Linux/macOS:

```bash
bash install/install-codex.sh /path/to/my-web-app
```

Prompts:

```text
Use $perfect-ai-master. Read references/16-animejs-api-matrix.md, 17-threejs-production-guide.md, 18-color-decision-engine.md and the relevant specialized skills. Build real animations and 3D; enforce monochrome for Perfect_AI; test responsiveness, performance, accessibility, and reverse scrolling. Report tests actually run.
```

## 2. VibeFarsi original code — install ALL items into your React app (without MCP)

**Requirement:** a separate compatible React + Tailwind CSS v4 app, Node/npm installed and internet available to download the CLI and packages. Commit/back up your app first. The script's normal mode only *prints* planned commands:

```powershell
.\install\install-vibefarsi-all.ps1 -ProjectPath "C:\Projects\my-web-app"
```

To execute after reviewing the plan:

```powershell
.\install\install-vibefarsi-all.ps1 -ProjectPath "C:\Projects\my-web-app" -Execute
```

To install only component groups (more practical):

```powershell
.\install\install-vibefarsi-all.ps1 -ProjectPath "C:\Projects\my-web-app" -Execute -OnlyCategories animations,components
```

The official CLI (`npx vibefarsi@latest init`, `npx vibefarsi add <slug>`) writes source files into *your target app*. The bulk script logs unavailable slugs; registry may change over time. **Do not confuse our 279 implementation cards with the 279 original source files.** Local source is portable without MCP after fetching dependencies.

Linux/macOS preview: `bash install/install-vibefarsi-all.sh /path/to/app`; execute: `bash install/install-vibefarsi-all.sh /path/to/app --execute`.

## 3. Import an upstream GitHub skill (optional)

```powershell
.\install\import-github-skill.ps1 -ProjectPath "C:\Projects\my-web-app" -Repo "obra/superpowers" -SkillPath "skills/systematic-debugging" -ApproveLicense
```

Before using this, independently inspect specific upstream license; the bundled GitHub catalog lists *candidates and references*, not a promise that every repository's content is freely redistributable. The script does not run upstream install scripts.

## 4. Color science / selection CLI

```bash
node tools/create-palette.mjs --monochrome --product=developer
node tools/create-palette.mjs --product=finance --light
node --test tests/color-engine.test.mjs
```

Color decision order: user brand constraint → accessibility/contrast → intended emotional/product context → semantic token palette → harmony and rendering check. Uses OKLCH chroma search to fit sRGB, not a palette generator that simply makes random gradients.

## 5. Run 3D motion example

```bash
cd examples/live-lab
npm install
npm run dev
```

Requires package downloads once. Do not claim pixel-identical animejs.com geometry: the sample is independent and inspired by the library feature families.

## 6. Validate package

```bash
python tools/validate_pack.py
node --test tests/color-engine.test.mjs
node --test skills/perfect-ai-master/examples/scroll-controller.test.mjs
```

`node --check examples/live-lab/src/main.js` validates syntax only. Browser visuals and npm dependency resolution require a compatible machine with internet/npm cache.

## Upstream sources / author rights

- https://animejs.com/documentation/ — Anime.js v4 APIs; original library https://github.com/juliangarnier/anime (MIT).
- https://threejs.org/docs/ — Three.js systems, https://github.com/mrdoob/three.js.
- https://vibefarsi.ir/docs and https://vibefarsi.ir/skills — official no-connector CLI and catalog; https://github.com/TronIsHere/vibefarsiui (MIT per repo README; verify actual files).
- https://github.com/vercel-labs/agent-skills , https://github.com/obra/superpowers , https://github.com/nextlevelbuilder/ui-ux-pro-max-skill — upstream skills/patterns selected as curated references; copied source is **not included**.

**Accurate boundary:** source of all possible Anime.js/Three.js animations is not a finite bundle; new custom animations are generated by writing application code. The package details official API families and individual named VibeFarsi patterns plus implementations/starter examples, not every proprietary demo script or asset embedded in the sites.
